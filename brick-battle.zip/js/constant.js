const GRAVITY = 6;
